require(["purchase"], function(purchase){
    console.log("starting in main");
    purchase.purchaseProduct();
});