define(function () {
  console.log("Function : getCredits");
  return {
    getCredits: function () {
      var credits = "100";
      console.log("in credits " + credits);
      return credits;
    },
  };
});
